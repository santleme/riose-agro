Generated on 2025-06-02 by Benaissa Said

Recommended citation for the dataset: [To be completed upon Zenodo publication]

*********************
GENERAL INFORMATION
*********************

1.1. Dataset title:
Accelerometer-Derived Behavioral Classification of Grazing and Ruminating in Dairy Cows – XGain WP5

1.2. Authorship
	Principal Author
		Name: Benaissa Said
		Address: ILVO – Flanders Research Institute for Agriculture, Fisheries and Food
		Email: said.benaissa@ilvo.vlaanderen.be


	Co-Author
		Name: Jarissa Maselyne
		Address: ILVO – Flanders Research Institute for Agriculture, Fisheries and Food
		Email: jarissa.maselyne@ilvo.vlaanderen.be


1.3. Dataset language: 
English

1.4. Abstract:
This dataset contains accelerometer data collected from 10 multiparous Holstein cows fitted with Axivity AX3 sensors mounted on neck collars. The cows were monitored during pasture access periods (07:30–14:00 daily) over a three-week period in April 2024 at ILVO (Melle, Belgium). Accelerometer data were sampled at 12.5 Hz and processed using a supervised decision-tree classifier developed for resource-constrained environments. Behavioral classifications include grazing and ruminating activities. The dataset supports real-time in-situ classification and provides a foundation for developing edge-based livestock behavior monitoring tools.

1.5. Keywords:
Cattle behavior, accelerometer, real-time classification, grazing, ruminating, AX3, machine learning, decision tree, PLF, XGain

1.6. Date of data collection: 
May-June-2024

1.7. Publication Date: 
[To be filled upon Zenodo upload]

1.8. Funder
	Funder name: European Union’s Horizon 2020 Research and Innovation Programme – XGain Project
	Project identifier: 101060294

1.9. Geographical location/s of data collection:
Melle, Flanders, Belgium

*************************
DATA ACCESS INFORMATION
*************************

2.1. Licenses / restrictions placed on access to the dataset:
CC BY-NC

2.2. Dataset DOI:
10.5281/zenodo.15600573

2.3. Publications that use the data


2.4. Other publicly accessible locations of the data


2.5. Link to related datasets
	

2.6. Were data derived from another source?:
No

****************************
METHODOLOGICAL INFORMATION
****************************

3.1. Describe the methods for data collection:
Each of the 10 cows was equipped with an Axivity AX3 accelerometer collar logging 3-axis motion data at 12.5 Hz. Behavioral observations were simultaneously recorded by trained observers to generate ground-truth labels. Animals grazed daily from 7:30 AM to 2:00 PM on pasture at ILVO. The classification algorithm was trained and validated using labeled segments.

3.2. Data processing methods:
Raw acceleration data were segmented into fixed-length windows and passed through a lightweight decision-tree algorithm designed for on-device inference. Output labels (grazing, ruminating) were appended to each segment. Data were exported as one-hour slices in individual `.xlsx` files per cow.

3.3. Software or instrument information:
- Axivity AX3 firmware v1.2
- Custom Python preprocessing script
- In-house decision tree model (resource-optimized)
- MATLAB
- Microsoft Excel 365 for data packaging

3.4. Standards and calibration information:
Default Axivity calibration was used. Devices were synchronized before deployment using standard AX3 protocol.

3.5. Quality-assurance procedures:
Sensor attachment was inspected daily. Accelerometer drift was periodically checked. Observational validation ensured label consistency across cows and sessions.

3.6. Analysis methods:
Each time-series was parsed into overlapping windows. Features (e.g., signal magnitude area, variance) were extracted and classified using a supervised decision tree. Labeling was cross-checked with observed behavior logs to validate the classifier's performance.

************************
SUMMARY OF DATA FILES
************************

4.1. If the dataset includes multiple files, outline the directory structure:
Root/
├── proc_data_66031_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66618_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66624_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66626_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66627_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66628_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66635_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66650_1h_Start_May_31_00_00_00.xlsx
├── proc_data_66720_1h_Start_May_31_00_00_00.xlsx
└── proc_data_66734_1h_Start_May_31_00_00_00.xlsx

4.2. File/folder list
    File name: proc_data_66031_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66031 (1-hour slice)

	File name: proc_data_66618_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66618 (1-hour slice)

	File name: proc_data_66624_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66624 (1-hour slice)

	File name: proc_data_66626_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66626 (1-hour slice)

	File name: proc_data_66627_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66627 (1-hour slice)

	File name: proc_data_66628_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66628 (1-hour slice)

	File name: proc_data_66635_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66635 (1-hour slice)

	File name: proc_data_66650_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66650 (1-hour slice)

	File name: proc_data_66720_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66720 (1-hour slice)

	File name: proc_data_66734_1h_Start_May_31_00_00_00.xlsx  
	Short description: Behavior data (ruminating, grazing, resting) for cow ID 66734 (1-hour slice)


4.3. Relationship between files/folders:
Each file corresponds to a single cow and represents the same synchronized time slice (1 hour). All files use a consistent structure for comparative analysis.

4.4. Information about multiple versions of the same file
Version 1. These files represent the processed and labeled outputs of the first analysis run. Future versions may include full-day or merged sequences.

****************************************
MORE INFORMATION
****************************************
This dataset was generated to support real-time behavioral monitoring of grazing livestock using low-power embedded systems. It is suitable for training/testing behavior classifiers, validating wearable sensor performance, or simulating edge-deployment scenarios.
